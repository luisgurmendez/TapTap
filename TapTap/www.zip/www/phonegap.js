/**
 *  This file should not be included in PhoneGap Build.
 *  Its use is for compatibility with webapps.
 *  
 *  Este archivo no debe ser incluido en PhoneGap Build.
 *  Su uso es para compatibilidad con las webapps.
 */